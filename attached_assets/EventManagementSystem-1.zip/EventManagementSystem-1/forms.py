from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SelectField, BooleanField, IntegerField, FloatField, DateTimeField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length, NumberRange, ValidationError, Optional
from wtforms.widgets import DateTimeLocalInput
from datetime import datetime
from models import User, UserRole, EventType, DressCode, EventLocation

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Login')

class SignupForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=25)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    password2 = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    role = SelectField('Role', choices=[(role.name, role.value.replace('_', ' ').title()) for role in UserRole if role != UserRole.ADMIN], validators=[DataRequired()])
    submit = SubmitField('Sign Up')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Username already exists. Please choose a different one.')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Email already registered. Please choose a different one.')

class ForgotPasswordForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    submit = SubmitField('Reset Password')

class ResetPasswordForm(FlaskForm):
    password = PasswordField('New Password', validators=[DataRequired(), Length(min=6)])
    password2 = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Reset Password')

class ContactForm(FlaskForm):
    name = StringField('Your Name', validators=[DataRequired(), Length(max=100)])
    email = StringField('Email Address', validators=[DataRequired(), Email()])
    subject = StringField('Subject', validators=[DataRequired(), Length(max=200)])
    message = TextAreaField('Message', validators=[DataRequired(), Length(min=10, max=1000)], render_kw={"rows": 6, "placeholder": "Tell us how we can help you..."})
    submit = SubmitField('Send Message')

class EventForm(FlaskForm):
    name = StringField('Event Name', validators=[DataRequired(), Length(max=200)])
    description = TextAreaField('Description', validators=[DataRequired()], render_kw={"rows": 4})
    date = DateTimeField('Start Date & Time', validators=[DataRequired()], format='%Y-%m-%dT%H:%M', widget=DateTimeLocalInput())
    end_date = DateTimeField('End Date & Time', validators=[DataRequired()], format='%Y-%m-%dT%H:%M', widget=DateTimeLocalInput())
    venue = StringField('Venue', validators=[DataRequired(), Length(max=200)])
    event_type = SelectField('Event Type', choices=[(type.name, type.value.replace('_', ' ').title()) for type in EventType], validators=[DataRequired()])
    dress_code = SelectField('Dress Code', choices=[(code.name, code.value.replace('_', ' ').title()) for code in DressCode], validators=[DataRequired()])
    location_type = SelectField('Location Type', choices=[(loc.name, loc.value.replace('_', ' ').title()) for loc in EventLocation], validators=[DataRequired()])
    is_public = BooleanField('Public Event')
    is_free = BooleanField('Free Event', default=True)
    price = FloatField('Price ($)', validators=[Optional(), NumberRange(min=0)], default=0)
    total_tickets = IntegerField('Total Tickets', validators=[DataRequired(), NumberRange(min=1)])
    contact_phone = StringField('Contact Phone', validators=[Optional(), Length(max=20)])
    company_name = StringField('Company/Organization', validators=[Optional(), Length(max=200)])
    logo_url = StringField('Logo URL', validators=[Optional(), Length(max=500)])
    logo_file = FileField('Upload Logo', validators=[FileAllowed(['jpg', 'png', 'gif', 'jpeg'], 'Images only!')])
    invitation_only = BooleanField('Invitation Only')
    submit = SubmitField('Create Event')
    
    def validate_end_date(self, end_date):
        if self.date.data and end_date.data and end_date.data <= self.date.data:
            raise ValidationError('End date must be after start date.')
    
    def validate_date(self, date):
        if date.data and date.data <= datetime.now():
            raise ValidationError('Event date must be in the future.')
    
    def validate_price(self, price):
        if not self.is_free.data and (not price.data or price.data <= 0):
            raise ValidationError('Price must be greater than 0 for paid events.')
