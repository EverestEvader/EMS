import enum
import secrets
from datetime import datetime, timedelta
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db

class UserRole(enum.Enum):
    ADMIN = "admin"
    EVENT_CREATOR = "event_creator"
    ATTENDEE = "attendee"

class EventStatus(enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"
    EXPIRED = "expired"

class EventType(enum.Enum):
    CONFERENCE = "conference"
    WORKSHOP = "workshop"
    SEMINAR = "seminar"
    NETWORKING = "networking"
    TRAINING = "training"
    MEETING = "meeting"
    SOCIAL = "social"
    OTHER = "other"

class DressCode(enum.Enum):
    FORMAL = "formal"
    BUSINESS_CASUAL = "business_casual"
    CASUAL = "casual"
    SMART_CASUAL = "smart_casual"

class EventLocation(enum.Enum):
    INDOOR = "indoor"
    OUTDOOR = "outdoor"
    VIRTUAL = "virtual"
    HYBRID = "hybrid"

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.Enum(UserRole), nullable=False, default=UserRole.ATTENDEE)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reset_token = db.Column(db.String(100), unique=True)
    reset_token_expiry = db.Column(db.DateTime)
    
    # Relationships
    created_events = db.relationship('Event', backref='creator', lazy='dynamic', cascade='all, delete-orphan')
    registrations = db.relationship('EventRegistration', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if provided password matches hash"""
        return check_password_hash(self.password_hash, password)
    
    def is_admin(self):
        """Check if user is admin"""
        return self.role == UserRole.ADMIN
    
    def is_event_creator(self):
        """Check if user is event creator or admin"""
        return self.role in [UserRole.EVENT_CREATOR, UserRole.ADMIN]
    
    def generate_reset_token(self):
        """Generate password reset token"""
        self.reset_token = secrets.token_urlsafe(32)
        self.reset_token_expiry = datetime.utcnow() + timedelta(hours=1)
        return self.reset_token
    
    def __repr__(self):
        return f'<User {self.username}>'

class Event(db.Model):
    __tablename__ = 'events'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime, nullable=False)
    venue = db.Column(db.String(200), nullable=False)
    event_type = db.Column(db.Enum(EventType), nullable=False, default=EventType.OTHER)
    dress_code = db.Column(db.Enum(DressCode), nullable=False, default=DressCode.BUSINESS_CASUAL)
    location_type = db.Column(db.Enum(EventLocation), nullable=False, default=EventLocation.INDOOR)
    is_public = db.Column(db.Boolean, default=True)
    is_free = db.Column(db.Boolean, default=True)
    price = db.Column(db.Float, default=0.0)
    total_tickets = db.Column(db.Integer, nullable=False)
    available_tickets = db.Column(db.Integer, nullable=False)
    creator_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    status = db.Column(db.Enum(EventStatus), default=EventStatus.PENDING)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    contact_phone = db.Column(db.String(20))
    company_name = db.Column(db.String(200))
    logo_url = db.Column(db.String(500))
    invitation_only = db.Column(db.Boolean, default=False)
    expired_at = db.Column(db.DateTime)  # When the event was marked as expired
    
    # Relationships
    registrations = db.relationship('EventRegistration', backref='event', lazy='dynamic', cascade='all, delete-orphan')
    
    @property
    def is_upcoming(self):
        """Check if event is upcoming"""
        return self.date > datetime.utcnow()
    
    @property
    def is_ongoing(self):
        """Check if event is currently ongoing"""
        now = datetime.utcnow()
        return self.date <= now <= self.end_date
    
    @property
    def is_past(self):
        """Check if event has ended"""
        return self.end_date < datetime.utcnow()
    
    @property
    def is_expired(self):
        """Check if event should be considered expired (ended + grace period)"""
        if self.status == EventStatus.EXPIRED:
            return True
        # Event is expired if it ended more than 7 days ago
        grace_period = timedelta(days=7)
        return self.end_date + grace_period < datetime.utcnow()
    
    @property
    def days_until_cleanup(self):
        """Calculate days until event will be cleaned up"""
        if not self.is_past:
            return None
        grace_period = timedelta(days=7)
        cleanup_date = self.end_date + grace_period
        if cleanup_date < datetime.utcnow():
            return 0
        return (cleanup_date - datetime.utcnow()).days
    
    @property
    def registration_count(self):
        """Get number of registrations for this event"""
        return self.registrations.count()
    
    def register_user(self, user_id):
        """Register a user for this event"""
        if self.available_tickets <= 0:
            return False
        
        # Check if user is already registered
        existing_registration = EventRegistration.query.filter_by(
            event_id=self.id, user_id=user_id
        ).first()
        
        if existing_registration:
            return False
        
        # Create registration
        registration = EventRegistration(event_id=self.id, user_id=user_id)
        db.session.add(registration)
        
        # Update available tickets
        self.available_tickets -= 1
        
        try:
            db.session.commit()
            return True
        except Exception as e:
            db.session.rollback()
            return False
    
    def unregister_user(self, user_id):
        """Unregister a user from this event"""
        registration = EventRegistration.query.filter_by(
            event_id=self.id, user_id=user_id
        ).first()
        
        if not registration:
            return False
        
        db.session.delete(registration)
        self.available_tickets += 1
        
        try:
            db.session.commit()
            return True
        except Exception as e:
            db.session.rollback()
            return False
    
    def is_registered(self, user_id):
        """Check if user is registered for this event"""
        return EventRegistration.query.filter_by(
            event_id=self.id, user_id=user_id
        ).first() is not None
    
    def mark_as_expired(self):
        """Mark event as expired"""
        if self.status != EventStatus.EXPIRED:
            self.status = EventStatus.EXPIRED
            self.expired_at = datetime.utcnow()
            db.session.commit()
    
    def __repr__(self):
        return f'<Event {self.name}>'

class EventRegistration(db.Model):
    __tablename__ = 'event_registrations'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('events.id'), nullable=False)
    registered_at = db.Column(db.DateTime, default=datetime.utcnow)
    payment_verified = db.Column(db.Boolean, default=False)
    
    # Ensure unique registration per user per event
    __table_args__ = (db.UniqueConstraint('user_id', 'event_id', name='unique_user_event_registration'),)
    
    def __repr__(self):
        return f'<EventRegistration User:{self.user_id} Event:{self.event_id}>'
